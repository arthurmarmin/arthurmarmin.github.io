% Function that compute the value of the criterion in (W,H) given V
% The criterion is given by
%    D(V|WH) + lambda ||H||
% where D is the beta-divergence, lambda is a positive real parameter, and
% the norm on H is the l1-norm, i.e. the sum of all its elements.
% (H is a matrix with non-negative components in this context).
%
% Inputs
%  - V      : matrix V to factorize
%  - W      : matrix W in the factorization of V
%  - H      : matrix H in the factorization of V
%  - beta   : parameter of the beta divergence
%  - lambda : regularization parameter
%  - is_eps : boolen that indicates whether +eps should be used in the
%             arguments of the beta divergence for numerical stability
% Output
%  - res  : value of the criterion
function res = compute_crit_L1reg(V,W,H,beta,lambda,is_eps)
    if is_eps
        res = sum(beta_div(V+eps,W*H+eps,beta),'all') + lambda*sum(H,'all');
    else
        res = sum(beta_div(V,W*H,beta),'all') + lambda*sum(H,'all');
    end
end