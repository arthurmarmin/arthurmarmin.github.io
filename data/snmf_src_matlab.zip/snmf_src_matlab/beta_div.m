% Function that computes the beta-divergence of x and y
% Inputs
%  - x       : first argument of the beta-divergence
%  - y       : second argument of the beta-divergence
%  - beta    : parameter of the beta divergence
% Output
%  - div_res : beta divergence of x and y
function div_res = beta_div(x,y,beta)
    % Check that the parameter of the beta divergence is a real number
    if ~isreal(beta)
        my_stack = dbstack;
        fct_name = my_stack.name;
        error("Error in %s: The parameter beta must be a real scalar number.", fct_name);
    end
    
    if beta == 0
        div_res = x./y - log(x./y) - 1;
    elseif beta == 1
        div_res = x.*log(x./y) - x + y;
    else
        div_res = x.^beta/(beta*(beta-1)) + y.^beta/beta - x.*y.^(beta-1)/(beta-1);
    end
end