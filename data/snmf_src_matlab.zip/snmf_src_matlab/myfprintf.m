% Custom display function to print in a log file and in the standard output
% at the same time.
%  - fid : file identifier of the logfile
function myfprintf(fid,varargin)
    fprintf(fid, varargin{:});
	fprintf(1, varargin{:});
end