% Implementation of the method proposed in
% J. Le Roux, J. R. Hershey, F. Weninger, 
% "Sparse NMF - half-baked or well done?," 
% MERL Technical Report, TR2015-023, March 2015
% to solve the following optimization problem
%    min_{W,H} D(V|WL^{-1}H) + lambda ||H||
% where D is the beta-divergence, V is a FxN matrix, W a FxK matrix, H a
% KxN matrix and L a diagonal matrix whose diagonal entries are the
% l1-norm of the columns of W.
%
% Inputs
%  - V      : data matrix V
%  - beta   : parameter of the beta-divergence
%  - lambda : regularization parameter
%  - W_init : initialization point for W
%  - H_init : initialization point for H
% Outputs
%  - W    : estimated factor matrix W
%  - H    : estimated factor matrix H
%  - info : structure containing information about the iterations
%         --> info.iter   = numbers of iterations before convergence is reached
%         --> info.crit_t = list of criterion value at each iteration
function [W,H,info] = h_snmf_l1(V,beta,lambda,W_init,H_init)
    % --- Constant Definition --- %
    TOL      = 1E-5;
    MAX_ITER = 5000;
    
    % --- Initialization of the estimates --- %
    W = W_init;
    H = H_init;
    
    % --- Rescale the column of W --- %
    scale = vecnorm(W,1);
    W     = W ./ scale;
    H     = H .* scale';
    
    % --- Initialization of the criterion value --- %
    crit = Inf;
    
    % --- Initialization of the number of iterations --- %
    info.iter = 0;
    
    % --- Initialization of array to store criterion values --- %
    info.crit_t = [];
    
    is_conv = false;

    % --- MM method --- %
    while ~is_conv
        % --- Update estimate of H --- %
        V_tilde = W*H+eps;
        if beta == 1
            H = H .* (W'*(V./V_tilde)) ./ (sum(W,1)'+lambda);
        elseif beta == 0
            H = H .* (W'*(V.*V_tilde.^(beta-2))) ./ (W'*(1./V_tilde)+lambda);
        else
            H = H .* (W'*(V.*V_tilde.^(beta-2))) ./ (W'*V_tilde.^(beta-1)+lambda);
        end
        
        % --- Update estimate of W --- %
        V_tilde = W*H+eps;
        vone    = ones(size(W,1),1);
        % Use for l2 norm on columns of W
%         W       = W .* ((V_tilde.^(beta-2).*V)*H'+W.*(vone*vone'*(W.*(V_tilde.^(beta-1)*H')))) ./ (V_tilde.^(beta-1)*H'+W.*(vone*vone'*(W.*((V_tilde.^(beta-2).*V)*H'))));
        % Use for l1 norm on columns of W
        if beta == 1
            W = W .* ((V./V_tilde)*H'+(vone*vone'*(W.*sum(H,2)'))) ./ (sum(H,2)'+(vone*vone'*(W.*((V./V_tilde)*H'))));
        elseif beta == 0
            W = W .* ((V_tilde.^(beta-2).*V)*H'+(vone*vone'*(W.*((1./V_tilde)*H')))) ./ ((1./V_tilde)*H'+(vone*vone'*(W.*((V_tilde.^(beta-2).*V)*H'))));
        else
            W = W .* ((V_tilde.^(beta-2).*V)*H'+(vone*vone'*(W.*(V_tilde.^(beta-1)*H')))) ./ (V_tilde.^(beta-1)*H'+(vone*vone'*(W.*((V_tilde.^(beta-2).*V)*H'))));
        end
        W = W ./ vecnorm(W,1);
        
        % --- Update the criterion value --- %
        crit_old = crit;
        crit     = compute_crit_L1reg(V,W,H,beta,lambda,true);
 
        % --- Store the new value of the criterion --- %
        info.crit_t = [info.crit_t crit];
        
        % --- Update the number of iterations --- %
        info.iter = info.iter + 1;

        % --- Check the stopping criterion --- %
        if abs(crit_old-crit)/crit < TOL
            is_conv = true;
        end
        if info.iter > MAX_ITER
            is_conv = true;
        end
    end
end