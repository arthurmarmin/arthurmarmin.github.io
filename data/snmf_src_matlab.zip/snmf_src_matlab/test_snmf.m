% Compute the NMF (Non-negative matrix factorization) V = WH by solving the
% following optimisation problem
%    min_{W,H} D(V|WH) + lambda ||H||
%      s.t.    (for all k in {1,...,K}) ||w_k|| = 1
% where D is the beta-divergence, V is a FxN matrix, W a FxK matrix, and H
% a KxN matrix.
% The vectors w_k are the columns of the matrix W, lambda is the
% regularization parameter, and the norm are all taken as the l1-norm.


% ============================== Clean-up =============================== %
close all
clear
clc
% ======================================================================= %


% ============================== Constants ============================== %
F        = 50;
N        = 40;
K        = 10;
BETA     = 1;
MAX      = 10;
LAMBDA_1 = 5;
LAMBDA_2 = 0.05;
EPSI     = 0.01;
NB_TESTS = 50;
NB_ALGO  = 5;
NAME_EXT = 'my_test_snmf';
% ======================================================================= %


% ======================================================================= %
%                               MAIN PROGRAM                              %
% ======================================================================= %

% ------------------------- Create data matrix V ------------------------ %
%  ----- Generate random synthetic data
W     = 0.5*MAX*abs(randn(F,K));
H     = 0.5*MAX*abs(sprandn(K,N,0.1));
V     = W*H;
V     = 0.5*MAX*abs(randn(F,N));

% ---- Load data from a spectrogram
% filename = 'data/FourOnSix.wav';
% V        = get_spectrogram(filename);
% V        = V + eps;

% ----- Load data from CBCL dataset
% impath = 'data/CBCL_dataset/faces/';
% V      = load_faces(impath);
% V=V+eps;

% ----- Load data from Olivetti faces dataset
% filename    = 'data/olivettifaces';
% main_struct = load(filename);
% V           = main_struct.faces;
% V(248,356)  = eps; % Correct the zero value in the database

% ----- Load data from Taste Profile dataset
%load data/data_tasteprofile

% ----- Load data from hypersepectral imaging
%  --- Load image Moffet --- %
% load data/Aviris_Moffet
% [N_row,N_col,F] = size(im);
% N = N_row*N_col;
% V = reshape(im(:,:,:),N,F)';
% % The data is noisy and contains a few negative values
% % these values are arbitrarily thresholded
% V(V<0) = 0;
% % Removal of frequency bands with insignificant energy
% mask = [1:4 104:115 151:175 205:222]; 
% V(mask,:) = [];
% V = V+eps;
% --- Load image Madonna --- %
% load data/Hyspex_Madonna
% [N_row,N_col,F] = size(im);
% N = N_row*N_col;
% V = double(reshape(im(:,:,:),N,F)');
% V = V+1;

% [F,N] = size(V);


% ----------------- Create a logfile to save the output ----------------- %
LOGFILE = ['result_snmf_',NAME_EXT,'_',datestr(now, 'dd-mm-yyyy'),'.txt'];
fid     = fopen(LOGFILE,'w');

% ------------------ Log information about the problem ------------------ %
myfprintf(fid,"Initial problem data:\n");
if BETA == floor(BETA)
    myfprintf(fid,"  --> Beta = %d\n", BETA);
else
    myfprintf(fid,"  --> Beta = %.3f\n", BETA);
end
myfprintf(fid,"  --> N       = %d\n",   N);
myfprintf(fid,"  --> F       = %d\n",   F);
myfprintf(fid,"  --> K       = %d\n",   K);
myfprintf(fid,"  --> Lambda1 = %g\n",   LAMBDA_1);
myfprintf(fid,"  --> Lambda2 = %g\n",   LAMBDA_2);

% ---------------- Initialize structures to save results ---------------- %
time = zeros(NB_TESTS,NB_ALGO);
crit = zeros(NB_TESTS,NB_ALGO);
err  = zeros(NB_TESTS,NB_ALGO);
iter = zeros(NB_TESTS,NB_ALGO);
% Array to save initializations
W_init_tab = cell(NB_TESTS,1);
H_init_tab = cell(NB_TESTS,1);

for test_id = 1:NB_TESTS
    % ----------------- Initialization of the estimates ----------------- %
    W_init = 0.5*MAX*abs(randn(F,K)) + eps;
    H_init = 0.5*MAX*abs(randn(K,N)) + eps;
    % Save initializations
    W_init_tab{test_id} = W_init;
    H_init_tab{test_id} = H_init;

    % ------------------------- Apply MM-SNMF-L1 ------------------------ %
    % (MM method on the criterion beta-divergence + lamba l1(H,'all'))
    tic;
    [W_sp0,H_sp0,info_sp0] = mm_snmf_l1(V+eps,BETA,LAMBDA_1,W_init,H_init,false);
    time_sp0               = toc;

    % ------------------------- Apply H-SNMF-L1 ------------------------- %
    % (Algorithm from "Sparse NMF - half-baked or well done?")
    tic;
    [W_sp1,H_sp1,info_sp1] = h_snmf_l1(V+eps,BETA,LAMBDA_1,W_init,H_init);
    time_sp1               = toc;

    % ------------------------- Apply L-SNMF-L1 ------------------------- %
    % My implementation of the Lagrangian method from the paper
    % "Multiplicative Updates for NMF with β-Divergences under Disjoint Equality Constraints"
    % for our problem.
    tic
    [W_sp2,H_sp2,info_sp2] = l_snmf_l1(V+eps,BETA,LAMBDA_1,W_init,H_init);
    time_sp2               = toc;
    
    % ------------------------ Apply MM-SNMF-Log ------------------------ %
    tic;
    [W_sp3,H_sp3,info_sp3] = mm_snmf_log(V,BETA,LAMBDA_2,EPSI,W_init,H_init);
    time_sp3               = toc;
 
    % ------------------------ Apply H-SNMF-Log ------------------------- %
    tic;
    [W_sp4,H_sp4,info_sp4] = h_snmf_log(V,BETA,LAMBDA_2,EPSI,W_init,H_init);
    time_sp4               = toc;

    % ---------------- Compute normalized criterion value --------------- %
    crit_val_t    = NaN(NB_ALGO,1);
    crit_val_t(1) = compute_crit_L1reg(V,W_sp0,H_sp0,BETA,LAMBDA_1,true) / (F*N);
    crit_val_t(2) = compute_crit_L1reg(V,W_sp1,H_sp1,BETA,LAMBDA_1,true) / (F*N);
    crit_val_t(3) = compute_crit_L1reg(V,W_sp2,H_sp2,BETA,LAMBDA_1,true) / (F*N);
    
    crit_val_t(4) = compute_crit_Logreg(V,W_sp3,H_sp3,BETA,LAMBDA_2,EPSI,true) / (F*N);
    crit_val_t(5) = compute_crit_Logreg(V,W_sp4,H_sp4,BETA,LAMBDA_2,EPSI,true) / (F*N);
    
    % -------------------------- Print results -------------------------- %
    myfprintf(fid,"# ===== Test %d ===== #\n",test_id);
    myfprintf(fid,">>> MM-NMF\n");
    myfprintf(fid,"  Number of iterations = %d\n",  info_sp0.iter);
    myfprintf(fid,"  Time (in seconds)    = %.3f\n",time_sp0);
    myfprintf(fid,"  Normalized Criterion = %.3f\n",crit_val_t(1));
    

    myfprintf(fid,">>> H-NMF (my impl.)\n");
    myfprintf(fid,"  Number of iterations = %d\n",  info_sp1.iter);
    myfprintf(fid,"  Time (in seconds)    = %.3f\n",time_sp1);
    myfprintf(fid,"  Normalized Criterion = %.3f\n",crit_val_t(2));

    myfprintf(fid,">>> L-SNMF\n");
    myfprintf(fid,"  Number of iterations = %d\n",  info_sp2.iter);
    myfprintf(fid,"  Time (in seconds)    = %.3f\n",time_sp2);
    myfprintf(fid,"  Normalized Criterion = %.3f\n",crit_val_t(3));
    
    myfprintf(fid,">>> Log MM-NMF\n");
    myfprintf(fid,"  Number of iterations = %d\n",  info_sp3.iter);
    myfprintf(fid,"  Time (in seconds)    = %.3f\n",time_sp3);
    myfprintf(fid,"  Normalized Criterion = %.3f\n",crit_val_t(4));

    myfprintf(fid,">>> Log H-NMF\n");
    myfprintf(fid,"  Number of iterations = %d\n",  info_sp4.iter);
    myfprintf(fid,"  Time (in seconds)    = %.3f\n",time_sp4);
    myfprintf(fid,"  Normalized Criterion = %.3f\n",crit_val_t(5));
    
    
    % -------------------------- Store results -------------------------- %    
    crit(test_id,:) = crit_val_t;
    time(test_id,:) = [time_sp0 time_sp1 time_sp2 time_sp3 time_sp4];
    iter(test_id,:) = [info_sp0.iter info_sp1.iter info_sp2.iter info_sp3.iter info_sp4.iter];
end

avg_time = mean(time);
std_time = std(time);
myfprintf(fid,">>> Average Running Time (in seconds)\n");
myfprintf(fid,"  MM-NMF       = %.3f (%.3f)\n",avg_time(1),std_time(1));
myfprintf(fid,"  H-NMF        = %.3f (%.3f)\n",avg_time(2),std_time(2));
myfprintf(fid,"  L-NMF        = %.3f (%.3f)\n",avg_time(3),std_time(3));
myfprintf(fid,"  Log MM-NMF   = %.3f (%.3f)\n",avg_time(4),std_time(4));
myfprintf(fid,"  Log H-NMF    = %.3f (%.3f)\n",avg_time(5),std_time(5));
avg_it = mean(iter);
std_it = std(iter);
myfprintf(fid,">>> Average number of iterations\n");
myfprintf(fid,"  MM-NMF       = %.3f (%.3f)\n",avg_it(1),std_it(1));
myfprintf(fid,"  H-NMF        = %.3f (%.3f)\n",avg_it(2),std_it(2));
myfprintf(fid,"  L-NMF        = %.3f (%.3f)\n",avg_it(3),std_it(3));
myfprintf(fid,"  Log MM-NMF   = %.3f (%.3f)\n",avg_it(4),std_it(4));
myfprintf(fid,"  Log H-NMF    = %.3f (%.3f)\n",avg_it(5),std_it(5));

% -------------------------- Close the logfile -------------------------- %
fclose(fid);

% ------------------- Save the results in a data file ------------------- %
result_file = ['results_info_',NAME_EXT,'.mat'];
save(result_file,'crit','time','iter','W_init_tab','H_init_tab');
% ======================================================================= %
