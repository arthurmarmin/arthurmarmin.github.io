% Implementation of the Lagrangian framework proposed in the paper
% "Multiplicative Updates for NMF with β-Divergences under Disjoint Equality Constraints"
% to solve the optimization problem
%    min_{W,H} D(V|WH) + lambda ||H||
%      s.t.    (for all k in {1,...,K}) ||w_k|| = 1
% where D is the beta-divergence, the norm are all taken as the l1-norm, 
% V is a FxN matrix, W a FxK matrix with w_k its columns, and H
% a KxN matrix.
%
% Inputs
%  - V      : data matrix V
%  - beta   : parameter of the beta-divergence
%  - lambda : regularization parameter
%  - W_init : initialization point for W
%  - H_init : initialization point for H
% Outputs
%  - W    : estimated factor matrix W
%  - H    : estimated factor matrix H
%  - info : structure containing information about the iterations
%         --> info.iter   = numbers of iterations before convergence is reached
%         --> info.crit_t = list of criterion value at each iteration
function [W,H,info] = l_snmf_l1(V,beta,lambda,W_init,H_init)
    % --- Constant Definition --- %
    TOL      = 1E-5;
    MAX_ITER = 5000;
    
    % --- Initialization of the estimates --- %
    W = W_init;
    H = H_init;
    
    % --- Initialization of the criterion value --- %
    crit = Inf;
    
    % --- Initialization of the number of iterations --- %
    info.iter = 0;
    
    % --- Initialization of array to store criterion values --- %
    info.crit_t = [];
    
    % --- Set up the value of the parameter gamma --- %
    if beta < 1
        gamma = 1/(2-beta);
    elseif beta > 2
        gamma = 1/(beta-1);
    else
        gamma = 1;
    end
    
    % --- Boolean to control the loop --- %
    is_conv = false;

    % --- MM method --- %
    while ~is_conv
        % --- Update estimate of H --- %
        Vt = W*H+eps;
        if beta == 1
            H = H .* (W'*(V./Vt)) ./ (sum(W,1)'+lambda);
        elseif beta == 0
            H = H .* (W'*(V.*Vt.^(beta-2))) ./ (W'*(1./Vt)+lambda);
        else
            H = H .* (W'*(V.*Vt.^(beta-2))) ./ (W'*Vt.^(beta-1)+lambda);
        end
        % --- Update estimate of W --- %
        Vt = W*H+eps;
        if beta == 1
            num   = (V./Vt)*H';
            denom = ones(size(V))*H';
        elseif beta == 0
            num   = (Vt.^(beta-2).*V)*H';
            denom = (1./Vt)*H';
        else
            num   = (Vt.^(beta-2).*V)*H';
            denom = Vt.^(beta-1)*H';
        end
        nu_0 = -1*ones(size(H,1),1); %min(denom.^(1/gamma)-num.^(1/gamma).*W)'; 
        nu   = compute_nu_opt(num,denom,W,nu_0,gamma);
        W    = W .* (num./(denom-ones(size(W,1),1)*nu')).^(gamma);
        
        % --- Update the criterion value --- %
        crit_old = crit;
        crit     = compute_crit_L1reg(V,W,H,beta,lambda,true);
        
        % --- Store the new value of the criterion --- %
        info.crit_t = [info.crit_t crit];
        
        % --- Update the number of iterations --- %
        info.iter = info.iter + 1;

        % --- Check the stopping criterion --- %
        if abs(crit_old-crit)/crit < TOL
            is_conv = true;
        end
        if info.iter > MAX_ITER
            is_conv = true;
        end
    end
end


% Auxiliary function to update the dual variables
% This function implement a Newton method
%
% Inputs
%  - num     : matrix (Vt.^(beta-2).*V)*H';
%  - denom   : matrix Vt.^(beta-1)*H';
%  - W       : factor matrix W
%  - nu_init : initial value for the dual variables
%  - gamma   : value of the parameter gamma depending on beta
% Ouput
%  - nu      : updated dual variables
function nu = compute_nu_opt(num,denom,W,nu_init,gamma)
    MAXITER = 100;
    TOL     = 1e-5;
    [F,K]   = size(num);
    vones   = ones(F,1);
    is_conv = false;
    iter    = 1;
    nu      = nu_init;
    while ~is_conv
        nu_old = nu;
        Mat    = W .* (num./(denom-vones*nu'+eps)).^gamma;
        r      = (sum(Mat,1)-ones(1,K))';
        tmp    = W .* (num./(denom-vones*nu'+eps)).^(gamma-1);
        Matp   = gamma*tmp.*num./(denom-vones*nu'+eps).^2;
        dr     = sum(Matp,1)';
        nu     = nu-r./(dr);
        if (max(abs(nu-nu_old)) <= TOL) || (iter<=MAXITER)
            is_conv = true;
        end
        iter = iter + 1;
    end
end