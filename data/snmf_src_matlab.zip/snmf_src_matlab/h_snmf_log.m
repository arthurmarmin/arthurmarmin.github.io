% Implementation of the method proposed in
% J. Le Roux, J. R. Hershey, F. Weninger, 
% "Sparse NMF - half-baked or well done?," 
% MERL Technical Report, TR2015-023, March 2015
% to solve the following optimization problem
%    min_{W,H} D(V|WL^{-1}H) + lambda .sum_{k,n}(log(h_{kn}+epsilon))
% where D is the beta-divergence, V is a FxN matrix, W a FxK matrix, H a
% KxN matrix and L a diagonal matrix whose diagonal entries are the
% l1-norm of the columns of W.
%
% Inputs
%  - V      : data matrix V
%  - beta   : parameter of the beta-divergence
%  - lambda : regularization parameter
%  - W_init : initialization point for W
%  - H_init : initialization point for H
% Outputs
%  - W    : estimated factor matrix W
%  - H    : estimated factor matrix H
%  - info : structure containing information about the iterations
%         --> info.iter   = numbers of iterations before convergence is reached
%         --> info.crit_t = list of criterion value at each iteration
function [W,H,info] = h_snmf_log(V,beta,lambda,epsilon,W_init,H_init)
    % --- Constant Definition --- %
    TOL      = 1E-5;
    MAX_ITER = 5000;
    
    % --- Initialization of the estimates --- %
    W = W_init;
    H = H_init;
    
    % --- Rescale the column of W --- %
    scale = vecnorm(W,1);
    W     = W ./ scale;
    H     = H .* scale';
    
    % --- Initialization of the criterion value --- %
    crit = Inf;
    
    % --- Initialization of the number of iterations --- %
    info.iter = 0;
    
    % --- Initialization of array to store criterion values --- %
    info.crit_t = [];
    
    is_conv = false;

    % --- MM method --- %
    while ~is_conv
        % --- Update estimate of H --- %
        Vt = W*H+eps;
        if beta == 1
            H = H .* (W'*(V./Vt)) ./ (sum(W,1)'+lambda./(H+epsilon));
        elseif beta == 0
            H = H .* (W'*(V.*Vt.^(beta-2))) ./ (W'*(1./Vt)+lambda./(H+epsilon));
        else
            H = H .* (W'*(V.*Vt.^(beta-2))) ./ (W'*Vt.^(beta-1)+lambda./(H+epsilon));
        end
        % --- Update estimate of W --- %
        Vt = W*H+eps;
        vone    = ones(size(W,1),1);
%         W       = W .* ((V_tilde.^(beta-2).*V)*H'+W.*(vone*vone'*(W.*(V_tilde.^(beta-1)*H')))) ./ (V_tilde.^(beta-1)*H'+W.*(vone*vone'*(W.*((V_tilde.^(beta-2).*V)*H'))));
        if beta == 1
            W = W .* ((V./Vt)*H'+(vone*vone'*(W.*(ones(size(V))*H')))) ./ (ones(size(V))*H'+(vone*vone'*(W.*((V./Vt)*H'))));
        elseif beta == 0
            W = W .* ((Vt.^(beta-2).*V)*H'+(vone*vone'*(W.*((1./Vt)*H')))) ./ ((1./Vt)*H'+(vone*vone'*(W.*((Vt.^(beta-2).*V)*H'))));
        else
            W = W .* ((Vt.^(beta-2).*V)*H'+(vone*vone'*(W.*(Vt.^(beta-1)*H')))) ./ (Vt.^(beta-1)*H'+(vone*vone'*(W.*((Vt.^(beta-2).*V)*H'))));
        end        
        W = W ./ vecnorm(W,1);
        
        % --- Update the criterion value --- %
        crit_old = crit;
        crit     = compute_crit_Logreg(V,W,H,beta,lambda,epsilon,true);
        
        % --- Store the new value of the criterion --- %
        info.crit_t = [info.crit_t crit];
        
        % --- Update the number of iterations --- %
        info.iter = info.iter + 1;

          % --- Check the stopping criterion --- %
        if abs(crit_old-crit)/abs(crit) < TOL
            is_conv = true;
        end
        if info.iter > MAX_ITER
            is_conv = true;
        end
    end
end