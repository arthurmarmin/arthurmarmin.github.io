% Implementation of the Majorization-Minimization method to solve the
% following optimization problem
%    min_{W,H} D(V|WH) + lambda sum_{k,n}(log(lambda_k h_{kn}+a))
% where D is the beta-divergence, V is a FxN matrix, W a FxK matrix, H a
% KxN matrix and lambda_k is the % l1-norm of the k-th column of W.
%
% Inputs
%  - V       : data matrix V
%  - beta    : parameter of the beta-divergence
%  - lambda  : regularization parameter
%  - W_init  : initialization point for W
%  - H_init  : initialization point for H
%  - is_heur : boolean that indicates whether the heuristics should be used
%              for the parameter gamma
% Outputs
%  - W    : estimated factor matrix W
%  - H    : estimated factor matrix H
%  - info : structure containing information about the iterations
%         --> info.iter   = numbers of iterations before convergence is reached
%         --> info.crit_t = list of criterion value at each iteration
function [W,H,info] = mm_snmf_log(V,beta,lambda,epsilon,W_init,H_init)
    % --- Constant Definition --- %
    TOL      = 1E-5;
    MAX_ITER = 5000;
    
    % --- Initialization of the estimates --- %
    W = W_init;
    H = H_init;
    
    % --- Initialization of the criterion value --- %
    scale    = vecnorm(W,1);
    crit     = compute_crit_Logreg(V,W./scale,H.*scale',beta,lambda,epsilon,true);
    crit_old = Inf;
    
    % --- Initialization of the number of iterations --- %
    info.iter = 0;
    
    % --- Initialization of array to store criterion values --- %
    info.crit_t = [crit];
    
    % --- Set up the value of the parameter gamma --- %
    if beta<1
        gamma = 1/(2-beta);
    elseif beta>2
        gamma = 1/(beta-1);
    else
        gamma = 1;
    end

    % --- MM method --- %
    while abs(crit_old-crit)/abs(crit) > TOL
        if beta == 1
            % --- Update estimate of H --- %
            U = W'*ones(size(V));
            H = H.*(W'*(V./(W*H+eps)))./(W'*ones(size(V))+lambda./(H+epsilon./U));
            % --- Update estimate of W --- %
            U = W'*ones(size(V));
            W = W.*((V./(W*H+eps))*H')./(ones(size(V))*H' +lambda*ones(size(V))*(1./(U+epsilon./H))');
        elseif beta == 0
            % --- Update estimate of H --- %
            Vt = W*H+eps;
            U  = W'*ones(size(V));
            H  = H.* ((W'*(V.*Vt.^(-2))) ./ (W'*(1./Vt)+lambda./(H+epsilon./U))).^(1/2);
            % --- Update estimate of W --- %
            U  = W'*ones(size(V));
            Vt = W*H+eps;
            W  = W.*(((V.*Vt.^(-2))*H') ./ ((1./Vt)*H'+lambda*ones(size(V))*(1./(U+epsilon./H))')).^(1/2);
        else
            % --- Update estimate of H --- %
            Vt = W*H+eps;
            U  = W'*ones(size(V));
            p  = W'*(V.*Vt.^(beta-2));
            q  = W'*(Vt.^(beta-1))+lambda./(H+epsilon./U);
            H  = H.*(p./q).^gamma;
            % --- Update estimate of W --- %
            Vt = W*H+eps;
            p  = (V.*Vt.^(beta-2))*H';
            q  = (Vt.^(beta-1))*H'+lambda*ones(size(V))*(1./(U+epsilon./H))';
            W  = W.*(p./q).^gamma;
        end   
        
        % --- Update the criterion value --- %
        crit_old = crit;
        crit     = compute_crit_Logreg(V,W,H,beta,lambda,epsilon,true);
        
        % --- Store the new value of the criterion --- %
        info.crit_t = [info.crit_t crit];
        
        % --- Update the number of iterations --- %
        info.iter = info.iter + 1;

        if info.iter > MAX_ITER
            break
        end
    end

    % --- Rescale W to avoid scaling issues --- %
    scale = vecnorm(W,1);
    W     = W ./ scale;
    H     = H .* scale';
end