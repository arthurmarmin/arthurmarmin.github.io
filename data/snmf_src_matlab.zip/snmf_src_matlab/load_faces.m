% Function that loads the image of CBCL data set into a data matrix
%
% Input
%  - impath : path to the folder containing the images
% Output
%  - X      : the data matrix
function X = load_faces(impath)
    X=zeros(19*19,2429); % F by N
    [~,N] = size(X);

    for i = 1:N
        if(i<10000 && i>=1000)
            zerostring = '0';
        elseif(i<1000 && i>=100)
            zerostring = '00';
        elseif(i<100 && i>=10)
            zerostring = '000';
        elseif(i<10)
            zerostring = '0000';
        end

        str = [impath 'face' zerostring num2str(i) '.pgm'];
        x = double(imread(str));

        % Normalization (as in Lee & Seung, 1999)
        x = x(:);
        x =  0.25 * (x-mean(x))/std(x) + 0.25;
        x = min(x,1);
        x = max(x,eps);

        X(:, i) = x;
    end
end