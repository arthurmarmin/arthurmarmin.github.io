% Function that computes the value of the auxiliary function at the point
% ((W,H), (W_t,H_t)) based on the parameter beta of the divergence 
%  - V    : data matrix V
%  - W    : matrix W of the first point
%  - H    : matrix H of the first point
%  - W_t  : matrix W of the second point
%  - H_t  : matrix H of the second point
%  - beta : parameter of the beta divergence used in the criterion
%  - res  : value of the auxiliary funtion at the point ((W,H), (W_t,H_t))
function res = compute_aux_fct(V,W,H,W_t,H_t,beta)
    F = size(W,2);
    N = size(H,2);
    
    V_t = W_t'*H_t;
    
    res = 0;
    for f = 1:F
        for n = 1:N
            lambda =  W_t(:,f).*H_t(:,n)/V_t(f,n);
            if beta == 1
                res = res + V_t(f,n) ...
                     + [H_t(:,n);W_t(:,f)]'*([W(:,f);H(:,n)]-[W_t(:,f);H_t(:,n)]) ...
                     + norm(([W(:,f);H(:,n)]-[W_t(:,f);H_t(:,n)]),2)^2 ...
                     - V(f,n)*sum(lambda.*log(W(:,f).*H(:,n)./lambda)) ...
                     + V(f,n)*(log(V(f,n))-1);
                 % For Jnt. Ex. 2
%                 res = res + W(:,f)'*H(:,n) - V(f,n)*sum(lambda.*log(W(:,f).*H(:,n)./lambda)) + V(f,n)*(log(V(f,n))-1);
            elseif beta == 0
                res = res + V(f,n)*sum(lambda.^2./(W(:,f).*H(:,n))) ...
                     + [H_t(:,n);W_t(:,f)]'*([W(:,f);H(:,n)]-[W_t(:,f);H_t(:,n)])/V_t(f,n) ...
                     + norm(([W(:,f);H(:,n)]-[W_t(:,f);H_t(:,n)]),2)^2/V_t(f,n) ...
                     + log(V_t(f,n))-log(V(f,n))-1;
            elseif beta < 1
                res = res + (W_t(:,f)'*H_t(:,n))^beta/beta ...
                    + (W_t(:,f)'*H_t(:,n))^(beta-1)*[H_t(:,n);W_t(:,f)]'*([W(:,f);H(:,n)]-[W_t(:,f);H_t(:,n)]) ...
                     - V(f,n)/(beta-1)*sum(lambda.*(W(:,f).*H(:,n)./lambda).^(beta-1)) ...
                     + V(f,n)^beta/(beta*(beta-1));
            elseif (beta > 1) && (beta <= 2)
                res = res + sum(lambda.*(W(:,f).*H(:,n)./lambda).^beta)/beta ...
                     - V(f,n)/(beta-1)*sum(lambda.*(W(:,f).*H(:,n)./lambda).^(beta-1)) ...
                     + V(f,n)^beta/(beta*(beta-1));
            else
                res = res + sum(lambda.*(W(:,f).*H(:,n)./lambda).^beta)/beta ...
                     + V(f,n)*V_t(f,n)^(beta-1)*(2-1/(beta-1)) ...
                     - V(f,n)*(W_t(:,f)'*H_t(:,n))^(beta-2)*(H_t(:,n)'*W(:,f)+W_t(:,f)'*H(:,n)) ...
                     + V(f,n)^beta/(beta*(beta-1));
            end
        end
    end
end