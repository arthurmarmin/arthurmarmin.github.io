function V = get_spectrogram(filename)
    % Select the samples
    OFFSET   = 44100*17;
    LENGTH   = 44100*5;
    samples       = [OFFSET,OFFSET+LENGTH];
    % Extract the samples
    [y,samp_rate] = audioread(filename,samples);
    % Select only a single channel in case the music file contains several ones.
    y = y(:,1);

    % Compute the spectrogram of the signal
    sg = 1024;
    ov = 768;
    s = spectrogram(y,sg,ov,[],samp_rate,'onesided');
    % Return the magnitudes of the spectrogram
    V = abs(s).^2;
end
