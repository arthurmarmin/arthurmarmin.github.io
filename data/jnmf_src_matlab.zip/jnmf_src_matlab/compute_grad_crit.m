% Function that computes the value of the gradient of the criterion
% at the point(W,H) based on the parameter beta of the divergence 
%  - V      : data matrix V
%  - W      : matrix W
%  - H      : matrix H
%  - beta   : parameter of the beta divergence used in the criterion
%  - grad_W : value of the gradient of the criterion wrt W at the
%             point (W,H)
%  - grad_H : value of the gradient of the criterion wrt H at the
%             point (W,H)
function [grad_W,grad_H] = compute_grad_crit(V,W,H,beta)
    F = size(W,2);
    N = size(H,2);
    K = size(W,1);
    
    grad_W = zeros(size(W));
    for f = 1:F
        for k = 1:K
            if beta == 1
                grad_W(k,f) = sum(H(k,:)-V(f,:).*H(k,:)./(W(:,f)'*H),2);
            else
                error('Computation of the gradient of the criterion is not yet available for beta not equal to 1');
            end
        end
    end
    
    grad_H = zeros(size(H));
    for n = 1:N
        for k = 1:K
            if beta == 1
                for f = 1:F
                    grad_H(k,n) = grad_H(k,n) + W(k,f) - V(f,n)*W(k,f)/(W(:,f)'*H(:,n));
                end
                grad_H(k,n) = sum(W(k,:)-V(:,n)'.*W(k,:)./(H(:,n)'*W));
            else
                error('Computation of the gradient of the criterion is not yet available for beta not equal to 1');
            end
        end
    end
end