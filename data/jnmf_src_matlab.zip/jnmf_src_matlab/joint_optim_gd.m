% Function that compute the NMF W'*H of V using a joint MM method
% Each minimization step is solved with a single step gradient descend.
%  - V      : initial matrix to factorize
%  - beta   : parameter of the beta divergence used in the criterion
%  - W_init : initial estimation of factor matrix W
%  - H_init : initial estimation of factor matrix H
%  - W_est  : estimated factor matrix W
%  - H_est  : estimated factor matrix V
%  - info   : structure containing information on the iterations
%      --> info.iter = number of iterations when convergence is reached
function [W_est,H_est,info] = joint_optim_gd(V,beta,W_init,H_init)
    % --- Constant Definition --- %
    TOL       = 1E-3;
    ARMIJ_CST = 0.6;
    STEP_DEC  = 0.9;
    
    % --- Initialization of the estimates --- %
    W_est = W_init;
    H_est = H_init;
    
    % --- Initialization of the criterion value --- %
    crit     = compute_crit(V,W_est,H_est,beta);
    crit_old = Inf;
    
    % --- Initialization of the number of iterations --- %
    info.iter = 0;
    
    % --- Initialization of array to store criterion values --- %
    info.crit_t = [crit];
    
    % --- MM method --- %
    while (crit_old-crit)/crit > TOL
        % Compute the gradient of the auxiliary function
        [grad_W,grad_H] = compute_grad_aux(V,W_est,H_est,beta);
        
        % Perform the descent with Armijo linesearch
        step = 1;
        while ~all(W_est-step*grad_W>0,'all') || ...
              ~all(H_est-step*grad_H>0,'all') || ...
              (compute_aux_fct(V,W_est-step*grad_W,H_est-step*grad_H,W_est,H_est,beta) ...
              >compute_aux_fct(V,W_est,H_est,W_est,H_est,beta)-ARMIJ_CST*step*norm([grad_W(:);grad_H(:)],'fro')^2)
            step = STEP_DEC * step;
        end

        % --- Update the matrices with gradient descent --- %
        W_est = W_est - step*grad_W;
        H_est = H_est - step*grad_H;
        
        % --- Rescale W to avoid scaling issues --- %
        scale = vecnorm(W_est',2);
        W_est = (W_est' ./ scale)';
        H_est =  H_est  .* scale';
        
        % --- Update the criterion value --- %
        crit_old = crit;
        crit     = compute_crit(V,W_est,H_est,beta);
        
        % --- Store the new value of the criterion --- %
        info.crit_t = [info.crit_t crit];
        
        % --- Update the number of iterations --- %
        info.iter = info.iter + 1;
    end
end