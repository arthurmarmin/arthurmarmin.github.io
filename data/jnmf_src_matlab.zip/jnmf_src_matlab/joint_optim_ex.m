% Function that compute the NMF W'*H of V using a joint MM method.
% The minimization step is performed with the exact solutions of polynomial
% systems.
%  - V     : initial matrix to factorize
%  - beta  : parameter of the beta divergence used in the criterion
%  - W_init : initial estimation of factor matrix W
%  - H_init : initial estimation of factor matrix H
%  - W_est : estimated factor matrix W
%  - H_est : estimated factor matrix V
%  - info  : structure containing information on the iterations
%      --> info.iter = number of iterations when convergence is reached
function [W_est,H_est,info] = joint_optim_ex(V,beta,W_init,H_init)
    % --- Constant Definition --- %
    F   = size(V,1);
    N   = size(V,2);
    K   = size(W_init,1);
    TOL = 1E-3;
    
    % --- Initialization of the estimates --- %
    W_est = W_init;
    H_est = H_init;
    
    % --- Initialization of the criterion value --- %
    crit     = compute_crit(V,W_est,H_est,beta);
    crit_old = Inf;
    
    % --- Initialization of the number of iterations --- %
    info.iter = 0;
    
    % --- Initialization of array to store criterion values --- %
    info.crit_t = [crit];
    
    % --- MM method --- %
    while (crit_old-crit)/crit > TOL
        % --- Build V_t in order to compute coefficients lambda --- %
        V_t = W_est'*H_est;
        % --- Save the value of the current estimates for W and H --- %
        W_old = W_est;
        H_old = H_est;
        if beta == 1
            % --- Solve the quadratic equations given by FOC --- %
            % Quadratic equations on the coefficients of W
            for f = 1:F
                lambda     = W_old(:,f).*H_old ./ V_t(f,:);
                coef_a     = N*ones(K,1);
                coef_b     = sum(H_old,2)-N*W_old(:,f);
                coef_c     = -sum(V(f,:).*lambda,2);
                delta      = coef_b.^2 - 4*coef_a.*coef_c;
                W_est(:,f) = (-coef_b+sqrt(delta)) ./ (2*coef_a);
            end
            % Quadratic equations on the coefficients of H
            for n = 1:N
                lambda     = (H_old(:,n).*W_old)' ./ V_t(:,n);
                coef_a     = F*ones(K,1);
                coef_b     = sum(W_old,2)-F*H_old(:,n);
                coef_c     = -sum(V(:,n).*lambda,1)';
                delta      = coef_b.^2 - 4*coef_a.*coef_c;
                H_est(:,n) = (-coef_b+sqrt(delta)) ./ (2*coef_a);
            end
        elseif beta == 0
            % --- Solve the quadratic equations given by FOC --- %
            % Quadratic equations on the coefficients of W
            for f = 1:F
                for k = 1:K
                    lambda     = W_old(k,f)*H_old(k,:) ./ V_t(f,:);
                    coef_a     = 1/sum(V_t(f,:));
                    coef_b     = sum(H_old(k,:)./V_t(f,:)-W_old(k,f)./V_t(f,:));
                    coef_c     = -sum(V(f,:).*lambda.^2./H_old(k,:));
                    sols       = roots([coef_a coef_b 0 coef_c]);
                    W_est(k,f) = sols(1);
                end
            end
            % Quadratic equations on the coefficients of H
            for n = 1:N
                for k = 1:K
                    lambda     = W_old(k,:)'*H_old(k,n) ./ V_t(:,n);
                    coef_a     = 1/sum(V_t(:,n));
                    coef_b     = sum(W_old(k,:)'./V_t(:,n)-H_old(k,n)./V_t(:,n));
                    coef_c     = -sum(V(:,n).*lambda.^2./W_old(k,:)');
                    sols       = roots([coef_a coef_b 0 coef_c]);
                    H_est(k,n) = sols(1);
                end
            end
        else
            error("Error in %s: The exact version is only implemented for beta=0 or beta=1.");
        end
        
        % --- Rescale W to avoid scaling issues --- %
        scale = vecnorm(W_est',2);
        W_est = (W_est' ./ scale)';
        H_est =  H_est  .* scale';

        % --- Update the criterion value --- %
        crit_old = crit;
        crit     = compute_crit(V,W_est,H_est,beta);
        
        % --- Store the new value of the criterion --- %
        info.crit_t = [info.crit_t crit];
        
        % --- Update the number of iterations --- %
        info.iter = info.iter + 1;
    end
end