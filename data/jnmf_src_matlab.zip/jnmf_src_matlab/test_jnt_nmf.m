% ============================== Clean-up =============================== %
close all
clear
clc
% ======================================================================= %


% ============================== Constants ============================== %
MAX      = 10;
F        = 50;
N        = 40;
K        = 3;
BETA     = 1;
NB_TESTS = 25;
NAME_EXT = 'synth_data';
% ======================================================================= %


% ======================================================================= %
%                               MAIN PROGRAM                              %
% ======================================================================= %

% ------------------------- Create data matrix V ------------------------ %
% Generate random synthetic data
W = 0.5*MAX*abs(randn(K,F));
H = 0.5*MAX*abs(randn(K,N));
V = W'*H;

% Load data from a spectrogram
% filename = 'data/FourOnSix.wav';
% V        = get_spectrogram(filename);
% V        = V + eps;

% Load data from CBCL dataset
% impath = 'data/CBCL_dataset/faces/';
% V      = load_faces(impath);
% V=V+eps;

% Load data from Olivetti faces dataset
% filename    = 'data/olivettifaces';
% main_struct = load(filename);
% V           = main_struct.faces;
% V(248,356)  = eps; % Correct the zero value in the database

% Load data from Movie Lens dataset
% load data/data_movielens_small
% V = V+eps;

% Load data from Taste Profile dataset
% load data/data_tasteprofile
% KAPPA = 1;
% V     = V + KAPPA;
% Do not forget to add +kappa in the definition of lambda tilde in
% joint_optim_mix()!

% Load data from hypersepectral imaging
% Load image Moffet
% load data/Aviris_Moffet
% [N_row,N_col,F] = size(im);
% N = N_row*N_col;
% V = reshape(im(:,:,:),N,F)';
% % The data is noisy and contains a few negative values
% % these values are arbitrarily thresholded
% V(V<0) = 0;
% % Removal of frequency bands with insignificant energy
% mask = [1:4 104:115 151:175 205:222]; 
% V(mask,:) = [];
% V = V+eps;
% Load image Madonna
% load data/Hyspex_Madonna
% [N_row,N_col,F] = size(im);
% N = N_row*N_col;
% V = double(reshape(im(:,:,:),N,F)');
% V = V+1;

% [F,N] = size(V);

% ----------------- Create a logfile to save the output ----------------- %
LOGFILE = ['result_jnt-nmf_',NAME_EXT,'_',datestr(now, 'dd-mm-yyyy'),'.txt'];
fid     = fopen(LOGFILE,'w');

% ------------------ Log information about the problem ------------------ %
fprintf(fid,"Initial problem data:\n");
fprintf(fid,"  --> Beta = %.3f\n", BETA);
fprintf(fid,"  --> N    = %d\n",   N);
fprintf(fid,"  --> F    = %d\n",   F);
fprintf(fid,"  --> K    = %d\n",   K);

% ----------------------- Check auxiliary function ---------------------- %
% Check numerically whether the auxiliary function is well-suited for MM
% method.
% Comment/Uncomment to skip/perform the check
% check_aux_fct(BETA);

% ---------------- Initialize structures to save results ---------------- %
time    = zeros(NB_TESTS,3);
crit    = zeros(NB_TESTS,3);
err     = zeros(NB_TESTS,3);
kkt_res = zeros(NB_TESTS,2,3);

for test_id = 1:NB_TESTS
    % ----------------- Initialization of the estimates ----------------- %
    W_init = 0.5*MAX*abs(randn(K,F));
    H_init = 0.5*MAX*abs(randn(K,N));
    
%     W_init = abs(1+rand(K,F));
%     H_init = abs(1+rand(K,N));

    % --------------------- Perform Alternating NMF --------------------- %
    tic;
    [W_alt,H_alt,info_alt] = alternat_optim(V,BETA,W_init,H_init);
    time_alt               = toc;

    % ------------------------ Perform Joint NMF ------------------------ %
    tic;
    [W_jnt,H_jnt,info_jnt] = joint_optim_mix(V,BETA,W_init,H_init);
    time_jnt               = toc;
    % ------------------ Perform Joint NMF Heuristirics ----------------- %
    tic;
    [W_heu,H_heu,info_heu] = joint_optim_mix_heur(V,BETA,W_init,H_init);
    time_heu               = toc;
    
    % -------------------- Compute the KKT residuals -------------------- %
    % Used to check convergence to a stationary point of the criterion
    [res_W_jnt,res_H_jnt] = compute_kkt_res(V,W_jnt,H_jnt,BETA);
    [res_W_alt,res_H_alt] = compute_kkt_res(V,W_alt,H_alt,BETA);
    [res_W_heu,res_H_heu] = compute_kkt_res(V,W_heu,H_heu,BETA);

    % --------------------- Compute relative errors --------------------- %
    err_alt = norm(W_alt'*H_alt-V,'fro') / norm(V,'fro');
    err_jnt = norm(W_jnt'*H_jnt-V,'fro') / norm(V,'fro');
    err_heu = norm(W_heu'*H_heu-V,'fro') / norm(V,'fro');

    % ---------------- Compute normalized criterion value --------------- %
    crit_val_alt = compute_crit(V,W_alt,H_alt,BETA) / (F*N);
    crit_val_jnt = compute_crit(V,W_jnt,H_jnt,BETA) / (F*N);
    crit_val_heu = compute_crit(V,W_heu,H_heu,BETA) / (F*N);
  
    % --------------- Check if the solutions are the same --------------- %
%     is_eq_W = is_eq_to_perm(W_alt,W_jnt);
%     is_eq_H = is_eq_to_perm(H_alt,H_jnt);
    
    % -------------------------- Print results -------------------------- %
    myfprintf(fid,"# ===== Test %d ===== #\n",test_id);
    myfprintf(fid,">>> Alternating MM method\n");
    myfprintf(fid,"  Number of iterations = %d\n",  info_alt.iter);
    myfprintf(fid,"  Time (in seconds)    = %.3f\n",time_alt);
    myfprintf(fid,"  Normalized Criterion = %.3f\n",crit_val_alt);
    myfprintf(fid,"  Relative error on V  = %.3f\n",err_alt);
    
    myfprintf(fid,">>> Joint MM method\n");
    myfprintf(fid,"  Number of iterations = %d\n",  info_jnt.iter);
    myfprintf(fid,"  Time (in seconds)    = %.3f\n",time_jnt);
    myfprintf(fid,"  Normalized Criterion = %.3f\n",crit_val_jnt);
    myfprintf(fid,"  Relative error on V  = %.3f\n",err_jnt);
    
    myfprintf(fid,">>> Joint MM method Heuristics\n");
    myfprintf(fid,"  Number of iterations = %d\n",  info_heu.iter);
    myfprintf(fid,"  Time (in seconds)    = %.3f\n",time_heu);
    myfprintf(fid,"  Normalized Criterion = %.3f\n",crit_val_heu);
    myfprintf(fid,"  Relative error on V  = %.3f\n",err_heu);
    
%     myfprintf(fid,"Are solutions W of both method the same? :  = %d\n",is_eq_W);
%     myfprintf(fid,"Are solutions H of both method the same? :  = %d\n\n",is_eq_H);
    
    % -------------------------- Store results -------------------------- %    
    crit(test_id,:) = [crit_val_alt crit_val_jnt crit_val_heu];
    time(test_id,:) = [time_alt time_jnt time_heu];
    err(test_id,:)  = [err_alt err_jnt err_heu];

    kkt_res(test_id,1,:) = [res_W_alt res_W_jnt res_W_heu];
    kkt_res(test_id,2,:) = [res_H_alt res_H_jnt res_H_heu];
end

% --- Close the logfile --- %
fclose(fid);

% --- Save the results in a data file --- %
result_file = ['results_info_',NAME_EXT,'.mat'];
save(result_file,'crit','err','time','info_jnt','info_alt','W_alt','H_alt','W_jnt','H_jnt');

% --------------------------- Plot the results -------------------------- %
f1 = figure('Name','Performance results');
% --- Display computational times
subplot(2,1,1);
bar(time);
set(gca,'yscale','log');
xlabel('Test ID');
ylabel('Computation time (in s)');
ylim([min(time,[],'all')-0.1,max(time,[],'all')])
% --- Display value of the criterion
subplot(2,1,2);
bar(crit);
set(gca,'yscale','log');
xlabel('Test ID');
ylabel('Normalized criterion');
% ylim([min(crit,[],'all')-0.1,max(crit,[],'all')])
% --- Display the relative on V 
% subplot(3,1,3);
% bar(err);
% set(gca,'yscale','log');
% xlabel('Test ID');
% ylabel('Relative error on V');
legend({'Alt.' 'Jnt.' 'JntInv.'});

f2 = figure('Name','KKT Residuals');
% --- Display KKT residual wrt W
subplot(2,1,1);
bar(squeeze(kkt_res(:,1,:)));
set(gca,'yscale','log');
xlabel('Test ID');
ylabel('KKT Residuals wrt W');
% --- Display KKT residual wrt H
subplot(2,1,2);
bar(squeeze(kkt_res(:,2,:)));
set(gca,'yscale','log');
xlabel('Test ID');
ylabel('KKT Residuals wrt H');
legend({'Alt.' 'Jnt.'});
% ======================================================================= %