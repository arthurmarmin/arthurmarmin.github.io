% Function that compute the NMF W'*H of V using a joint MM method
% (version 2).
% The minimization step is performed with the exact solutions of a linear
% systems.
%  - V     : initial matrix to factorize
%  - beta  : parameter of the beta divergence used in the criterion
%  - W_init : initial estimation of factor matrix W
%  - H_init : initial estimation of factor matrix H
%  - W_est : estimated factor matrix W
%  - H_est : estimated factor matrix V
%  - info  : structure containing information on the iterations
%      --> info.iter = number of iterations when convergence is reached
function [W_est,H_est,info] = joint_optim_mix(V,beta,W_init,H_init)
    % --- Constant Definition --- %
    TOL = 1E-5;
    
    % --- Initialization of the estimates --- %
    W_est = W_init;
    H_est = H_init;
    
    % --- Initialization of the criterion value --- %
    crit     = compute_crit(V,W_est,H_est,beta);
    crit_old = Inf;
    
    % --- Initialization of the number of iterations --- %
    info.iter = 0;
    
    % --- Initialization of array to store criterion values --- %
    info.crit_t = [crit];
    
    % --- MM method --- %
    while (crit_old-crit)/crit > TOL
        if beta == 1
            cst = V ./ (W_est'*H_est+eps);
            % --- Compute constants for the inner iterations --- %
            cst_W = W_est.*(cst*H_est')';
            cst_H = H_est.*(W_est*cst);
            % --- Update W and H alternatively --- %
            W_est = cst_W./sum(H_est,2);
            H_est = cst_H./sum(W_est,2);
        elseif beta == 0
            W_old  = W_est;
            H_old  = H_est;
            V_t    = W_old'*H_old+eps;
            inv_Vt = 1./V_t;
            qV     = V./V_t.^2;
            W_est  = W_est.*((qV*(H_old.^2./H_est)')./(inv_Vt*H_est')).^(0.5)';
            H_est  = H_est.*(((W_old.^2./W_est)*qV)./(W_est*inv_Vt)).^(0.5);
        elseif beta == 2
            W_old  = W_est;
            H_old  = H_est;
            V_t    = W_old'*H_old;
            W_est  = W_est.*((V*H_est')./(V_t*(H_est.^2./H_old)'))';
            H_est  = H_est.*((W_est*V)./((W_est.^2./W_old)*V_t));
        elseif beta < 1
            W_old  = W_est;
            H_old  = H_est;
            V_t    = W_old'*H_old;
            cst    = V./(V_t.^(2-beta));
            W_est  = W_est.*((cst*((H_est.^(beta-1))./(H_old.^(beta-2)))')./((V.^(beta-1))*H_old')).^(1/(2-beta))';
            H_est  = H_est.*((((W_est.^(beta-1))./(W_old.^(beta-2)))*cst)./(W_old*(V.^(beta-1)))).^(1/(2-beta));
        elseif beta < 2
            W_old  = W_est;
            H_old  = H_est;
            V_t    = W_old'*H_old;
            cst    = V./(V_t.^(2-beta));
            W_est  = W_est.*((cst*((H_est.^(beta-1))./(H_old.^(beta-2)))')./((V.^(beta-1))*H_est'))';
            H_est  = H_est.*((((W_est.^(beta-1))./(W_old.^(beta-2)))*cst)./(W_est*(V.^(beta-1))));
        else
            W_old  = W_est;
            H_old  = H_est;
            V_t    = W_old'*H_old;
            cst    = V./(V_t.^(2-beta));
            W_est  = W_est.*((cst*H_old')./((V.^(beta-1))*((H_est.^beta)./(H_old.^(beta-1)))')).^(1/(1-beta))';
            H_est  = H_est.*((W_old*cst)./(((W_est.^beta)./(W_old.^(beta-1)))*(V.^(beta-1)))).^(1/(1-beta));
        end

        % --- Rescale W to avoid scaling issues --- %
        scale = vecnorm(W_est',2);
        W_est = (W_est' ./ scale)';
        H_est =  H_est  .* scale';
        
        % --- Update the criterion value --- %
        crit_old = crit;
        crit     = compute_crit(V,W_est,H_est,beta);
        
        % --- Store the new value of the criterion --- %
        info.crit_t = [info.crit_t crit];
        
        % --- Update the number of iterations --- %
        info.iter = info.iter + 1;
    end
end