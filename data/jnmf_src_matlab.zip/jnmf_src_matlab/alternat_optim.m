% Function that compute the NMF W'*H of V using an alternating MM method
%  - V     : initial matrix to factorize
%  - beta  : parameter of the beta divergence used in the criterion
%  - W_init : initial estimation of factor matrix W
%  - H_init : initial estimation of factor matrix H
%  - W_est : estimated factor matrix W
%  - H_est : estimated factor matrix V
%  - info  : structure containing information on the iterations
%      --> info.iter = number of iterations when convergence is reached
function [W_est,H_est,info] = alternat_optim(V,beta,W_init,H_init)
    % --- Constant Definition --- %
    TOL = 1E-5;
    
    % --- Initialization of the estimates --- %
    W_est = W_init;
    H_est = H_init;
    
    % --- Initialization of the criterion value --- %
    crit     = compute_crit(V,W_est,H_est,beta);
    crit_old = Inf;
    
    % --- Initialization of the number of iterations --- %
    info.iter = 0;
    
    % --- Initialization of array to store criterion values --- %
    info.crit_t = [crit];
    
    % --- Set up the value of the parameter gamma --- %
    if beta < 1
        gamma = 1/(2-beta);
    elseif beta > 2
        gamma = 1/(beta-1);
    else
        gamma = 1;
    end

    % --- MM method --- %
    while (crit_old-crit)/crit > TOL
        if beta == 1
            % --- Update estimate of H --- %
            W_est = W_est.*((V./(W_est'*H_est+eps))*H_est')'./sum(H_est,2);
            % --- Update estimate of W --- %
            H_est = H_est.*(W_est*(V./(W_est'*H_est+eps)))./sum(W_est,2);
        else
            % --- Update estimate of H --- %
            V_tilde = W_est'*H_est+eps;
            p       = W_est*(V.*V_tilde.^(beta-2));
            q       = W_est*(V_tilde.^(beta-1));
            H_est   = H_est.*(p./q).^gamma;

            % --- Update estimate of W --- %
            V_tilde = W_est'*H_est+eps;
            p       = H_est*(V.*V_tilde.^(beta-2))';
            q       = H_est*(V_tilde.^(beta-1))';
            W_est   = W_est.*(p./q).^gamma;
        end
        
        % --- Rescale W to avoid scaling issues --- %
        scale = vecnorm(W_est',2);
        W_est = (W_est' ./ scale)';
        H_est =  H_est  .* scale';
        
        % --- Update the criterion value --- %
        crit_old = crit;
        crit     = compute_crit(V,W_est,H_est,beta);
        
        % --- Store the new value of the criterion --- %
        info.crit_t = [info.crit_t crit];
        
        % --- Update the number of iterations --- %
        info.iter = info.iter + 1;
    end
end