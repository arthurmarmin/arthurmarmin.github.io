% Function that numerically checks whether the auxiliary function is
% suitable for applying MM method on a beta-convergence criterion
%  - beta : parameter of the criterion
function check_aux_fct(beta)
    NB_TESTS    = 100;
    NB_SUBTESTS = 10;
    SCALE       = 10;
    TOL         = 1e-6;
    
    for test_id = 1:NB_TESTS
        % --- Random choice of the dimensions of the matrices --- %
        F = randi(100);
        N = randi(100);
        K = randi(max(1,floor(min(F,N)/3)));
    
        % --- Random initialization of the matrices  --- %
        W = 0.5*SCALE*abs(randn(K,F));
        H = 0.5*SCALE*abs(randn(K,N));
        V = 0.5*SCALE*abs(randn(K,F))'*0.5*SCALE*abs(randn(K,N));
        
        % --- Compute the criterion and its auxiliary function values --- %
        aux_fct_val_1 = compute_aux_fct(V,W,H,W,H,beta);
        crit_val      = compute_crit(V,W,H,beta);
        
        % --- Check that the auxiliary function is tangential --- %
        err_tan = abs(aux_fct_val_1-crit_val) > TOL;
        
        % --- Check that the auxiliary function is a majorization --- %
        err_ineq = false;
        for subtest_id = 1: NB_SUBTESTS
            % Add some perturbations on the matrix W and H to get a new
            % point
            W_pert = W + 0.1*abs(randn(K,F));
            H_pert = H + 0.1*abs(randn(K,N));
            % Compute the value of the auxiliary function with respect to
            % the new point
            aux_fct_val_2 = compute_aux_fct(V,W,H,W_pert,H_pert,beta);
                 
            % Check whether the previous value is higher than the
            % beta-divergence criterion value
            if aux_fct_val_2 - crit_val < -TOL
                err_ineq = true;
                break;
            end
        end
        
        % If the auxiliary function is not a tangential majorization,
        % return an error
        if err_tan || err_ineq
            error("The auxiliary function is not a tangential majorization of the beta-divergence criterion.")
        end
    end
    fprintf(1,"The auxiliary function is a correct tangential majorization of the beta-divergence criterion.\n\n");
end