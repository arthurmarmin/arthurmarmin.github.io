% Function that compute the criterion between V and W'*H based on beta-divergence 
%  - V    : matrix V to factorize
%  - W    : matrix W in the factorization of V
%  - H    : matrix H in the factorization of V
%  - beta : parameter of the beta divergence used in the criterion
%  - res  : beta divergence of x and y
function res = compute_crit(V,W,H,beta)
    res = sum(beta_div(V,W'*H,beta),'all');
end


% Function that compute the beta_divergence of x and y 
%  - x       : initial matrix to factorize
%  - y       : rank of the factorization
%  - beta    : parameter of the beta divergence
%  - div_res : beta divergence of x and y
function div_res = beta_div(x,y,beta)
    if ~isreal(beta)
        my_stack = dbstack;
        fct_name = my_stack.name;
        error("Error in %s: The parameter beta must be a real scalar number.", fct_name);
    end
    
    if beta == 0
        div_res = x./y - log(x./y) - 1;
    elseif beta == 1
        div_res = x.*log(x./y) - x + y;
    else
        div_res = x.^beta/(beta*(beta-1)) + y.^beta/beta - x.*y.^(beta-1)/(beta-1);
    end
end