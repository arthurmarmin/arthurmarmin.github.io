% Function that computes the value of the gradient of the auxiliary
% function at the point((W,H), (W_t,H_t)) based on the parameter beta of
% the divergence 
%  - V      : data matrix V
%  - W      : matrix W
%  - H      : matrix H
%  - beta   : parameter of the beta divergence used in the criterion
%  - grad_W : value of the gradient of the auxiliary funtion wrt W at the
%             point ((W,H), (W,H))
%  - grad_H : value of the gradient of the auxiliary funtion wrt H at the
%             point ((W,H), (W,H))
function [grad_W,grad_H] = compute_grad_aux(V,W,H,beta)
    F = size(W,2);
    N = size(H,2);
    
    V_t = W'*H;
    
    grad_W = zeros(size(W));
    for f = 1:F
        lambda = W(:,f).*H ./ V_t(f,:);
        if beta == 1
            grad_W(:,f) = sum(H - V(f,:).*lambda./W(:,f),2);
        elseif beta == 0
            grad_W(:,f) = sum(-V(f,:).*lambda.^2./(H.*W(:,f).^2) + H./V_t(f,:),2);
        elseif beta < 1
            grad_W(:,f) = sum(V_t(f,:).^(beta-1).*H-V(f,:).*H.*(H.*W(:,f)./lambda).^(beta-2),2);
        elseif (beta > 1) && (beta <= 2)
            grad_W(:,f) = sum(H.*(H.*W(:,f)./lambda).^(beta-1)-V(f,:).*H.*(H.*W(:,f)./lambda).^(beta-2),2);
        else
            grad_W(:,f) = sum(H.*(H.*W(:,f)./lambda).^(beta-1)-V(f,:).*V_t(f,:).^(beta-2).*W(:,f),2);
        end
    end
    
    grad_H = zeros(size(H));
    for n = 1:N
        lambda = (H(:,n).*W)' ./ V_t(:,n);
        if beta == 1
            grad_H(:,n) = sum(-V(:,n).*lambda./H(:,n)' + W')';
        elseif beta == 0
            grad_H(:,n) = sum(-V(:,n).*lambda.^2./(W.*H(:,n).^2)' + W'./V_t(:,n))';
        elseif beta < 1
            grad_H(:,n) = sum(V_t(:,n).^(beta-1).*W'-V(:,n).*W'.*((W.*H(:,n))'./lambda).^(beta-2))';
        elseif (beta > 1) && (beta <= 2)
            grad_H(:,n) = sum(W'.*((W.*H(:,n))'./lambda).^(beta-1)-V(:,n).*W'.*((W.*H(:,n))'./lambda).^(beta-2))';
        else
            grad_H(:,n) = sum(W'.*((W.*H(:,n))'./lambda).^(beta-1)-V(:,n).*V_t(:,n).^(beta-2).*H(:,n)')';
        end
    end
end