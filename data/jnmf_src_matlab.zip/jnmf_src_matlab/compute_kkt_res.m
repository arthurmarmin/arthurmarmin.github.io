% Function that computes the KKT residuals at the point (W,H)
%  - V     : data matrix V
%  - W     : matrix W in the factorization
%  - H     : matrix H in the factorization
%  - beta  : parameter of the beta divergence used in the criterion
%  - res_W : KKT residuals wrt W
%  - res_H : KKT residuals wrt H
function [res_W,res_H] = compute_kkt_res(V,W,H,beta)
    F = size(W,2);
    N = size(H,2);
    K = size(W,1);
    
    res_W = norm(min(W',((W'*H).^(beta-2).*(W'*H-V))*H'),1) / (K*F);
    res_H = norm(min(H , W*((W'*H).^(beta-2).*(W'*H-V))),1) / (K*N);
end