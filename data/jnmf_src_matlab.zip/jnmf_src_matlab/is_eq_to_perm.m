% Function that checks whether two matrices are equal up to permutation of
% their columns.
%  - A        : the first matrix
%  - B        : the second matrix
%  - is_equal : returned boolean
function is_equal = is_eq_to_perm(A,B)
    TOL   = 1e-0;
    [N,M] = size(A);

    costs = NaN(M);
    for m = 1:M
        costs(m,:) = vecnorm(A(:,m)-B,2);
    end
    
    G = matchpairs(costs,1e32);

    if G(:,1)' == 1:size(G,1)
        B_retr = B(:,G(:,2));
        err    = norm(A-B_retr,'fro')/(N*M);
    else
        A_retr = A(:,G(:,1));
        err    = norm(B-A_retr,'fro')/(N*M);
    end
    
    is_equal = false;
    if err < TOL
        is_equal = true;
    end
end